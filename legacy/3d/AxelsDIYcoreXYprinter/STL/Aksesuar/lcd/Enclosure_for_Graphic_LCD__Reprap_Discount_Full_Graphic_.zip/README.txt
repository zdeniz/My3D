                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2142542
Enclosure for Graphic LCD ( Reprap Discount Full Graphic ) by RuiJC is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Hi guys,
This is my enclosure for a reprap discount full graphic lcd.
It can be oriented and mounted in many different ways thanks to the flexible arm.
You need to rotate the front and back cover of the enclosure in your slicer before printing.

Here is a video of the assembly:
https://youtu.be/wvPMhgq8n6k

Note: On the frontal cover, i didnt include 2 of the inner holes for the screws because some displays have the holes shifted. When assembling you need to drill these 2 holes to match your display.

Note 2: I also uploaded the version of the frontal without the letters.

# Print Settings

Printer: Tevo Tarantula
Rafts: Doesn't Matter
Supports: No
Resolution: 0.15
Infill: 50%